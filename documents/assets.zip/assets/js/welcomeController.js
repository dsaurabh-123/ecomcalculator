//controller for welcome page
app.controller("welcomeController", function($scope) {
    
});
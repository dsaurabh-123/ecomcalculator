

//controller for amazon page

app.controller("amazonController", function($scope) {

    $scope.buyingPrice=0;
    $scope.sellingPrice=0;
    //$scope.shippingCharges=0;
    //$scope.referralFeesAmout=0;
    //$scope.fixClosingAmount=0;
    //$scope.total_with_tax=0;
    $scope.profit=0;

    

   // function to calculate profit based on user input

    $scope.Profit=function(){

        // function for shipping charge..........................
        // $scope.shippingCharges= function(){
        //     return 50;
        // }
                    
        //Tax amount calculate...........................
        $scope.total_with_tax=(18/100)*$scope.sellingPrice;
        console.log($scope.total_with_tax);
        //Hard coded for shipping Fix closing and Referal fee 
        $scope.shippingCharges=50;
        $scope.fixClosingAmount=20;
        $scope.referralFeesAmout=10;  

        $scope.profit=$scope.sellingPrice-$scope.buyingPrice-$scope.shippingCharges-$scope.fixClosingAmount-$scope.total_with_tax-$scope.referralFeesAmout;

        }
    
});
<?php
    require('dbx.php');
    require('config.php');
    require('functions.php');    
    /*require_once('resize_class.php');    */
    
?>